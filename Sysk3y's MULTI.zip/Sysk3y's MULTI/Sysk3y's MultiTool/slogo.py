
           .                     .  G:                              
          ;W                    ;W  E#,    :   L                    
         f#E  f.     ;WE.      f#E  E#t  .GE   #K:       f.     ;WE.
       .E#f   E#,   i#G      .E#f   E#t j#K;   :K#t      E#,   i#G  
      iWW;    E#t  f#f      iWW;    E#GK#f       L#G.    E#t  f#f   
     L##Lffi  E#t G#i      L##Lffi  E##D.         t#W,   E#t G#i    
    tLLG##L   E#jEW,      tLLG##L   E##Wi      .jffD##f  E#jEW,     
      ,W#i    E##E.         ,W#i    E#jL#D:   .fLLLD##L  E##E.      
     j#E.     E#G          j#E.     E#t ,K#j      ;W#i   E#G        
   .D#j       E#t        .D#j       E#t   jD     j#E.    E#t        
  ,WK,        E#t       ,WK,        j#t        .D#f      E#t        
  EG.         EE.       EG.          ,;        KW,       EE.        
  ,           t         ,                      G.        t          
                                                                       