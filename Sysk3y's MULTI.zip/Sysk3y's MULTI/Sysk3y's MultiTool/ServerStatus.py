[96;40m[[91;40m+[96;40m]Our Servers Are All Up An Runing[91;40m 100%[96;40m[[91;40m+[96;40m]
[96;40m         LINUX SERVER 1: [91;40mOK
[96;40m         LINUX SERVER 2: [91;40mOK
[96;40m         LINUX SERVER 3: [91;40mOK
[96;40m         LINUX SERVER 4: [91;40mOK
[96;40m         LINUX SERVER 5: [91;40mOK
[96;40m         LINUX SERVER 6: [91;40mOK    
[96;40m         LINUX SERVER 7: [91;40mOK 
[96;40m         LINUX SERVER 8: [91;40mOK
[96;40m         APIs: [91;40m120 
[96;40m         Total Bots: [91;40m28547696
