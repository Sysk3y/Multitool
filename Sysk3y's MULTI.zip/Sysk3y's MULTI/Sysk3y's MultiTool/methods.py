[96;40m                              Sysk3y's  Methods
[96;40m               ______________________________________________
[96;40m                    HOME           NFO               OVH
[96;40m 
[96;40m                 LKZ-ICMP      ANON-NFOUV1         LKZ-OVHV1
[96;40m                 LKZ-UDP       LKZ-NFOGSRV         OVHKILL
[96;40m                 LKZ-TCPALL    LKZ-OPENVPN        100UP-KILL
[96;40m                 LKZ-AMP 
[96;40m                 LKZ-UDPEAT
[96;40m                 UDPBYPASS
[96;40m                 TCPBYPASS